public enum Shape {
    Spades,
    Diamonds,
    Clubs,
    Hearts
}