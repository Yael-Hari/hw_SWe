public class Main {
    public static void main(String[] args) {
        SmallTest.setSeed(50);
        SmallTest.runTest();
    }
}
